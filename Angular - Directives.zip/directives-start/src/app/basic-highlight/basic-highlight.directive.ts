import { Directive, OnInit, ElementRef } from "@angular/core";

@Directive({
    selector: '[appBasicHighlight]'
})

export class BasicHighlightDirective implements OnInit {
    constructor(private elementRef: ElementRef) {}

    ngOnInit() {
        //Sometimes the environment we are working on may not allow the access to DOM. Then this direct access of element won't work!!
        this.elementRef.nativeElement.style.backgroundColor = 'aqua';  
    }
}