import { EventEmitter, Injectable } from '@angular/core';

import { Recipe } from "./recipe.model";
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';

@Injectable()
export class RecipeService {
    recipeSelected = new EventEmitter<Recipe>();

    recipes: Recipe[] = [
        new Recipe(
            'Pizza', 
            'American Favourite', 
            'https://cdn.apartmenttherapy.info/image/fetch/f_auto,q_auto:eco,c_fit,w_760/https%3A%2F%2Fstorage.googleapis.com%2Fgen-atmedia%2F3%2F2018%2F03%2F55cd28cae8ee78fe1e52ab1adc9eafff24c9af92.jpeg', 
            [
                new Ingredient('Dough', 1),
                new Ingredient('Cheeze', 4),
                new Ingredient('Pepperoni', 8),
                new Ingredient('Pizza Sauce', 1)
            ]),
        new Recipe(
            'Tiramisu', 
            'Italian Dessert', 
            'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRdHAgsp7bfzz3aUqP9t0uP9VMyeMi9aEc76WI_6kH7mbKofcrJ', 
            [
                new Ingredient('Flour', 5),
                new Ingredient('Coffee', 1),
                new Ingredient('Chocolate', 5),
                new Ingredient('Cream', 5)
            ])
    ];

    constructor(private slService: ShoppingListService) {}

    getRecipes() {
        return this.recipes.slice();
    }

    addIngredientsToShoppingList(ingredients: Ingredient[]) {
        this.slService.addIngredients(ingredients);
    }
}