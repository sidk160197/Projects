const key = '6bbddf9491cd70f267e1e6abd0eef16b';
const proxy = 'https://cors-anywhere.herokuapp.com/'